-- 1176850's Lua and Manifest Created by Hubcap Manifest
-- GOOSE.IO
-- Created: September 29, 2025 at 15:11:28 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1176850) -- GOOSE.IO
-- MAIN APP DEPOTS
addappid(1176851, 1, "4e8db12c5a1cdcd614146edc1658ba14829060315c43f8ce03cc2722e8b42c34") -- GOOSE.IO Content
setManifestid(1176851, "7086112545337073024", 222158175)