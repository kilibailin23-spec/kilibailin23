-- 1222700's Lua and Manifest Created by Hubcap Manifest
-- A Way Out
-- Created: July 23, 2026 at 16:34:17 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 13
-- Total DLCs: 1
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1222700, 1, "296bde34d213d0b42f45b3520e72fc47bd6ba2ffa74db818964a883a373255ff") -- A Way Out
-- MAIN APP DEPOTS
addappid(1222701, 1, "296a25aab14d646738a1f6edfbf1e95ee086a91a389b9e661317bfe8f815fdf1") -- Telstar - AWO Content
setManifestid(1222701, "3337035757784335885", 22213699893)
addappid(1222702, 1, "6a5f802f2a712fd1c1a358f04f95b3adfad3323cf26ec0dfe0f4658397b05932") -- Telstar - AWO - English
setManifestid(1222702, "8387221094917375962", 139274)
addappid(1222703, 1, "fa535a948ef0b5bcaa8dbe4794a8f85f73980c6fb5bc33989f2dc0076eaf287a") -- Telstar - AWO - German
setManifestid(1222703, "5636124281960800039", 166855)
addappid(1222704, 1, "283c416a1884384cad6c501ce703eea1f2a4f50b46ca162b311174cd981c1f73") -- Telstar - AWO - Italian
setManifestid(1222704, "7343339097675540561", 151677)
addappid(1222705, 1, "bd8ae9979838b6612efec2cfd36f45269ad696cae02c662a1a65eba0b227f5f6") -- Telstar - AWO - Spanish
setManifestid(1222705, "3075867475302157756", 164499)
addappid(1222706, 1, "b0818998ff4fb445684d0c934c2f849d91395587a039bdf5634bcc681d9e7f25") -- Telstar - AWO - French
setManifestid(1222706, "8338245604001591508", 158102)
addappid(1222707, 1, "ae1d745331c0b50321eb288a201b3f7eb951a4b30a6e5364b170d95a52626261") -- Telstar - AWO - Polish
setManifestid(1222707, "8916018675485212397", 158612)
addappid(1222708, 1, "e3ee5a392f8c3f7b41e00471f7cae046bafacb9c95f453bc25b86f636fb121aa") -- Telstar - AWO - Brazilian Portuguese
setManifestid(1222708, "2402279825248928699", 147962)
addappid(1222709, 1, "1016cf4d540f6220afb5e18e6e3194b269abe6006996f4966e29728a29a65809") -- Telstar - AWO - Russian
setManifestid(1222709, "2661962776059232529", 238042)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "6717304605949129056", 240979991)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1225270) -- A Way Out - Key