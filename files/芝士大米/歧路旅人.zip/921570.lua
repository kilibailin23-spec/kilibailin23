-- 921570's Lua and Manifest Created by Hubcap Manifest
-- OCTOPATH TRAVELER
-- Created: September 30, 2025 at 04:25:14 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(921570) -- OCTOPATH TRAVELER
-- MAIN APP DEPOTS
addappid(921571, 1, "d68c52ab730016257e72ad98554e2a7d8cb6131790cc4490fff16873b73132b9") -- OCTOPATH TRAVELER Content
setManifestid(921571, "5896441090656338684", 3388171447)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- OCTOPATH TRAVELER DLC Pre-Purchase Wallpapers (AppID: 1083770)
addappid(1083770)
addtoken(1083770, "5048866756202704070")
addappid(1083770, 1, "233d3fdec4d0f87dbcbd2a2d77bb6d277ac034050c67ef93f7930a1952816eaf") -- OCTOPATH TRAVELER DLC Pre-Purchase Wallpapers - OCTOPATH TRAVELER Steam wallpaper files for pre-purchase (1083770) デポ
setManifestid(1083770, "639595591076631777", 183858333)