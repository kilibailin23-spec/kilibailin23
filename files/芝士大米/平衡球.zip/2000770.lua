-- 2000770's Lua and Manifest Created by Hubcap Manifest
-- Ballance
-- Created: September 29, 2025 at 00:01:38 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2000770) -- Ballance
-- MAIN APP DEPOTS
addappid(2000771, 1, "cd3e0cb07ab504552cc2159a81353daff01a6d4448632d91ae3b38c9e8a5e9cb") -- Depot 2000771
setManifestid(2000771, "7279483457589127941", 158337248)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)