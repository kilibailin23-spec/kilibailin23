-- 3431040's Lua and Manifest Created by Hubcap Manifest
-- That's not my Neighbor
-- Created: January 18, 2026 at 15:41:41 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3431040, 1, "e11ff1bef0f8523be9e1a62e1446b577bae26367d2c67887f002ba7350451c4f") -- That's not my Neighbor
-- MAIN APP DEPOTS
addappid(3431043, 1, "deb5b59ba0936b3ae251e701a13be2d2f24a8cbc021be1bc13e7925fda72745c") -- Depot 3431043
setManifestid(3431043, "8870970973599912143", 358983520)
addappid(3431045, 1, "b508cdfe4e9f20dc8e655da4aa5cd1e41833a3421485f79fc8039f69b1655ee3") -- Depot 3431045
setManifestid(3431045, "591281361236477397", 359962208)
addappid(3431047, 1, "5e7961ef262adf64c0b82ed8f8f7527db9e6f65f716068d6a9320bbe744c43e3") -- Depot 3431047
setManifestid(3431047, "3131244617883416287", 359962112)
addappid(3431041, 1, "cc51fcec3d8dda778605464eef88ae266cdbc612a843106a170839a7060289fc") -- Depot 3431041
setManifestid(3431041, "5213632607014064158", 359964992)
addappid(3431042, 1, "5bd556fdd5836d1e3abc4e4e086fd6f9fba21afbf7280e427b1e0c2865de4d3a") -- Depot 3431042
setManifestid(3431042, "376615255908550684", 367805088)