-- 260210's Lua and Manifest Created by Hubcap Manifest
-- Assassin's Creed Liberation
-- Created: August 24, 2026 at 11:36:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 1
-- Shared Depots: 5

-- MAIN APPLICATION
addappid(260210, 1, "65cfda07c56ae52841b2c373d294637b3d865e39555a91d2cd59607db3518b43") -- Assassin's Creed Liberation
-- MAIN APP DEPOTS
addappid(260211, 1, "6a3490285db760cc79bac0bdecd4f4bb729ee76363f8298ecf13e046213fd845") -- Assassin's Creed Liberation Content
setManifestid(260211, "2084186428532339486", 3211370537)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "768541678728958832", 264458224)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(272700) -- Assassins Creed Liberation HD - Bonus Pack