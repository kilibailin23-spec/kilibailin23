-- 431590's Lua and Manifest Created by Hubcap Manifest
-- Earn to Die 2
-- Created: November 27, 2025 at 12:49:12 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(431590) -- Earn to Die 2
-- MAIN APP DEPOTS
addappid(431591, 1, "8da2d4e9ea959bf5e5cdd8cf10f2c61d87d4c156309a0467356f42a7a185d18d") -- Earn to Die 2 common resources
setManifestid(431591, "5996233938899301389", 175737073)
addappid(431592, 1, "9e4c9c9fd0e0fb76d45dfc96c16a46f92932a6faf0b0772f6f82c11f87615e28") -- Earn to Die 2 Windows executables
setManifestid(431592, "7927234552816211578", 10867870)
addappid(431593, 1, "81ad5c7b3185990cbf32f50ae6d3c77a5f2f044015ad4b05d998b609b348d4db") -- Earn to Die 2 Mac OS X executables
setManifestid(431593, "3848995920975718051", 8829301)