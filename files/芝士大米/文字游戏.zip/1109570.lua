-- 1109570's Lua and Manifest Created by Hubcap Manifest
-- 《文字遊戲》
-- Branch: PUBLIC
-- Created: January 10, 2026 at 12:52:34 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(1109570, 1, "434a9c8a57340559362485355b2e52a7a957afca2ea5bc3599f15d2f8e9721d3") -- 《文字遊戲》
addtoken(1109570, "16537240222139241145")
-- MAIN APP DEPOTS
addappid(1109571, 1, "80164c3cba3c8e54a398cc2797ce86e94fddc318ae615cd4a376be0fedfae9bc") -- 文字遊戲 win
setManifestid(1109571, "4662967284228667036", 2152498504)
addappid(1109572, 1, "6634723f7faa6d9c38ee231fc0bb01805be928ef32d2d472478170b903ae78bd") -- 文字遊戲 mac
setManifestid(1109572, "5351250298021052759", 2204151442)
addappid(1109573, 1, "3d78421813021de678adffe80cbc3c0d5b9a7b5bf8462f64ca4a2dd9da25c101") -- Depot 1109573
setManifestid(1109573, "8133950152953150701", 2162165725)
-- DLCS WITH DEDICATED DEPOTS
--  (AppID: 1912740)
addappid(1912740)
addappid(1912740, 1, "0dac5bdfa4b604b2d33b612ea2b8b7646f6870bb2fc846a5fe95b0822eed8639") -- Depot 1912740
setManifestid(1912740, "8932907350680300016", 75201980)