-- 2384580's Lua and Manifest Created by Hubcap Manifest
-- DYNASTY WARRIORS: ORIGINS
-- Created: April 04, 2026 at 21:09:27 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 10
-- Total DLCs: 9 (4 excluded)
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2384580, 1, "a48f892e064b01728580d88a2c13d6a003d87d467d7b5a16703684926b74965f") -- DYNASTY WARRIORS: ORIGINS
-- MAIN APP DEPOTS
addappid(2384581, 1, "c9bfe8a78dc43f75438b3a8e602c7a322b0b53418f80be108058121a71371130") -- Depot 2384581
setManifestid(2384581, "3792757300936452338", 53669854694)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- DYNASTY WARRIORS ORIGINS - Protagonists Costume Nameless Warrior Garb (AppID: 3319840)
addappid(3319840)
addtoken(3319840, "8824614407371289400")
addappid(3319840, 1, "e3daad5e8a9c79487f8ea299232fe177f346a535339aced3dbb44b4123959142") -- DYNASTY WARRIORS ORIGINS - Protagonists Costume Nameless Warrior Garb - Depot 3319840
setManifestid(3319840, "4766733277274996871", 52441373)
-- DYNASTY WARRIORS ORIGINS - Early Works Soundtrack Collection (Digital Edition) (AppID: 3319850)
addappid(3319850)
addtoken(3319850, "10944105112804011624")
addappid(3319850, 1, "95133ff39c5da8ae0536933d236bb7eab7c1df24a6fedc606bcf5d0867c1a016") -- DYNASTY WARRIORS ORIGINS - Early Works Soundtrack Collection (Digital Edition) - Depot 3319850
setManifestid(3319850, "575849332506894225", 1138596568)
-- DYNASTY WARRIORS ORIGINS - Official Book (Digital Edition, Japanese version) (AppID: 3319860)
addappid(3319860)
addtoken(3319860, "525880456765100502")
addappid(3319860, 1, "eb5c039bb499de6dea3bb580083c831393d697ff12404bae8b7ffcc0d8fe9f28") -- DYNASTY WARRIORS ORIGINS - Official Book (Digital Edition, Japanese version) - Depot 3319860
setManifestid(3319860, "7820196852362389506", 30383077)
-- DYNASTY WARRIORS ORIGINS - Original Soundtrack (Digital Edition) (AppID: 3319870)
addappid(3319870)
addtoken(3319870, "1595971489372741222")
addappid(3319870, 1, "69380b72ac8cb5b3f7914bbb0e828d1529ef6b2a20076ceb73945c656515e5c7") -- DYNASTY WARRIORS ORIGINS - Original Soundtrack (Digital Edition) - Depot 3319870
setManifestid(3319870, "2027069962015143615", 150886376)
-- DYNASTY WARRIORS ORIGINS - Letters (AppID: 3319890)
addappid(3319890)
addtoken(3319890, "4925446025434514146")
addappid(3319890, 1, "ee47966cbf4e985ece4730ea8e94a7766202486517e1dba9de172b6fe849760d") -- DYNASTY WARRIORS ORIGINS - Letters - Depot 3319890
setManifestid(3319890, "1226171390310445224", 96)
-- DYNASTY WARRIORS ORIGINS - ICHIRAN Noodles (AppID: 3319940)
addappid(3319940)
addappid(3319940, 1, "3a41ae63aea1d4d9ba069358a1159daa92ead59d2790df626c089512e6018c1f") -- DYNASTY WARRIORS ORIGINS - ICHIRAN Noodles - Depot 3319940
setManifestid(3319940, "4542174949091178289", 48)
-- DYNASTY WARRIORS ORIGINS Visions of Four Heroes (AppID: 4038930)
addappid(4038930)
addappid(4038930, 1, "f9f14de8b63c682e209ed7e0b885d5abd784ee5f1f3b08a333eb5902acf60692") -- DYNASTY WARRIORS ORIGINS Visions of Four Heroes - Depot 4038930
setManifestid(4038930, "4884216548703729445", 5784155132)
-- DYNASTY WARRIORS ORIGINS - Protagonists Costume Yellow Turban Attire (AppID: 4101630)
addappid(4101630)
addappid(4101630, 1, "9e59d656348d3145eb23e69ece591c42ff3bc4b295de26c1d672729625f07fae") -- DYNASTY WARRIORS ORIGINS - Protagonists Costume Yellow Turban Attire - Depot 4101630
setManifestid(4101630, "6713619555578120475", 46823959)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3319880) -- DYNASTY WARRIORS ORIGINS - Official Book  Original Soundtrack (Digital Edition)
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- DYNASTY WARRIORS ORIGINS - Protagonists Costume Garb of the Azure Bird (AppID: 3319900) - missing depot keys
-- addappid(3319900)
-- DYNASTY WARRIORS ORIGINS - Protagonists Costume Garb of the Crimson Bird (AppID: 3319910) - missing depot keys
-- addappid(3319910)
-- DYNASTY WARRIORS ORIGINS - Protagonists Costume Garb of the Emerald Bird (AppID: 3319920) - missing depot keys
-- addappid(3319920)
-- DYNASTY WARRIORS ORIGINS - Protagonists Costume Garb of the Violet Bird (AppID: 3319930) - missing depot keys
-- addappid(3319930)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2530290) -- Depot 2530290 (empty depot)