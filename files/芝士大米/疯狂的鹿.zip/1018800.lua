-- 1018800's Lua and Manifest Created by Hubcap Manifest
-- DEEEER Simulator: Your Average Everyday Deer Game
-- Created: September 29, 2025 at 07:08:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1018800) -- DEEEER Simulator: Your Average Everyday Deer Game
-- MAIN APP DEPOTS
addappid(1018801, 1, "bcabe13fbca24e274d6f8500661f2e7dcb0d563d1df259cbedbe791ee05eb11b") -- DEEEER Simulator デポ
setManifestid(1018801, "4403239370224400278", 841460676)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1801910) -- The Final Evolution of DEEEER
addappid(3360410) -- DEEEER Simulator - SHIKANOKO DANCE DLC