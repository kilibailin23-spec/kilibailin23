-- 851640's Lua and Manifest Created by Hubcap Manifest
-- Marble Race
-- Created: September 29, 2025 at 23:42:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(851640, 1, "fbe84b60cf5e7f61e88f70b80442b8985c7b5b1434174e973c7ebe514a801436") -- Marble Race
-- MAIN APP DEPOTS
addappid(851641, 1, "793354dee20e9da79004a3535e678f9125b5f8d5e2437c62cc1806d717e34e1f") -- win 64
setManifestid(851641, "4259037696758154752", 214241209)