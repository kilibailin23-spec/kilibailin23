-- 4073860's Lua and Manifest Created by Hubcap Manifest
-- Sludgineers
-- Created: August 27, 2026 at 00:34:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4073860, 1, "727a00b6e623e92543b7ce515f973560301a457e5f697e1b1f00d8c0373e5b4f") -- Sludgineers
-- MAIN APP DEPOTS
addappid(4073861, 1, "da852f0a1697419dd86d310348f4bff6cad6d38e28b73bb29e76545d1973e0cb") -- Depot 4073861
setManifestid(4073861, "2640289198686955556", 822831901)
addappid(4073862, 1, "a58683ff4262867e752529f9b9d532f43fd5d611f2f767f1cfe249707cb88bdb") -- Depot 4073862
setManifestid(4073862, "3051851453686524338", 931971279)
addappid(4073863, 1, "08b8b3717233c2ce8780bde42a587c1ef9b36a9f41e8760089b42e972d313e14") -- Depot 4073863
setManifestid(4073863, "5141577763663415937", 867349566)