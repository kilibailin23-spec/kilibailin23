-- 1151990's Lua and Manifest Created by Hubcap Manifest
-- Slip 'n Slime
-- Created: March 16, 2026 at 17:47:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1151990) -- Slip 'n Slime
-- MAIN APP DEPOTS
addappid(1151992, 1, "a895fc667fc01cb9c52dece3d037501398a8def25950e1e7833d5f3512106d6f") -- Depot 1151992
setManifestid(1151992, "8520808121786131627", 1202611925)
addappid(1151993, 1, "ed23f9ca1070494a01a686e05bec2514e436af49a496c2c4d1be03e69721151e") -- Depot 1151993
setManifestid(1151993, "1388452947945637903", 1271492988)
addappid(1151994, 1, "33c1c8f09c2bc8b7f6049b26e5cdfea270e71569665665dd72c17db66b5cccdb") -- Depot 1151994
setManifestid(1151994, "8827350208089447890", 2381241392)