-- 1332720's Lua and Manifest Created by Hubcap Manifest
-- Thief Simulator 2
-- Created: October 01, 2025 at 01:33:19 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(1332720) -- Thief Simulator 2
-- MAIN APP DEPOTS
addappid(1332721, 1, "fa8baa603d576daf280269ec6d1581afea7eb9d1940f593ff8d3bbfb78339e14") -- Depot 1332721
setManifestid(1332721, "6652561021038637825", 15009970686)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3027860) -- Thief Simulator 2: Cruise Ship DLC (unreleased)