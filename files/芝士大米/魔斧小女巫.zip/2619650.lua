-- 2619650's Lua and Manifest Created by Hubcap Manifest
-- Cauldron
-- Created: June 25, 2026 at 23:48:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2619650, 1, "ac11932824ed8f80b56718311484b07dc17ab143ce6b9a2f0038270a977d5038") -- Cauldron
-- MAIN APP DEPOTS
addappid(2619651, 1, "918343dada47c356828b1df3d51c6692efc744449fe8c03d3cadc84846436aee") -- Depot 2619651
setManifestid(2619651, "2960703727490484489", 240877134)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2619652) -- Depot 2619652 (empty depot)