-- 2968420's Lua and Manifest Created by Hubcap Manifest
-- PowerWash Simulator 2
-- Created: July 16, 2026 at 11:32:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(2968420, 1, "d67e90e69712a46a9aeb2fc1e684d7432a88cd41dad7fbce89e0005ceb3b1322") -- PowerWash Simulator 2
-- MAIN APP DEPOTS
addappid(2968422, 1, "2c13dcc1b498282fe021b2cd49229d7309ace370d9e990cd3ad843397cf247c9") -- Depot 2968422
setManifestid(2968422, "2576393139753962022", 9480779896)
-- DLCS WITH DEDICATED DEPOTS
-- PowerWash Simulator 2 - Adventure Time Pack (AppID: 4173830)
addappid(4173830)
addappid(4173830, 1, "09117944c3966ed77061eb5f134fb9985cc1b2de5c9d48ac629139c66c1659b9") -- PowerWash Simulator 2 - Adventure Time Pack - Depot 4173830
setManifestid(4173830, "6742564778197930674", 447253259)
-- PowerWash Simulator 2 - STAR WARS Pack (AppID: 4229450)
addappid(4229450)
addappid(4229450, 1, "16aa57f7dc9215729cb0f06b7ff0a79b2af2fa0f0ec0bdfc0dad2ca3f14ea84c") -- PowerWash Simulator 2 - STAR WARS Pack - Depot 4229450
setManifestid(4229450, "961465766120031372", 1674489235)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4556380) -- Depot 4556380 (empty depot)