-- 296220's Lua and Manifest Created by Hubcap Manifest
-- Farm Frenzy 4
-- Created: September 29, 2025 at 11:45:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(296220) -- Farm Frenzy 4
-- MAIN APP DEPOTS
addappid(296221, 1, "d238a533bf0b1098a9d75d9f125cc0e9a47ea4c0ae57504439b1a4f5949100ff") -- Farm Frenzy 4 ENG
setManifestid(296221, "2928098657368005534", 784906157)
addappid(296222, 1, "f046cab6aa9899f7a8ce29a34fd0773a264e7000f2a07a669b57c78903c01347") -- Farm Frenzy 4 GER
setManifestid(296222, "8224213774781862100", 784906157)
addappid(296223, 1, "5e74afcfe1afa91abf2f090db4ddfd463badeed0b9d118de593d8173834c5b58") -- Farm Frenzy 4 JAP
setManifestid(296223, "7563283532630251661", 784906157)
addappid(296224, 1, "1ebece966e9fcb5e04799e0d6031f74345ebd928edb093cc35d83452d6b08477") -- Farm Frenzy 4 RUS
setManifestid(296224, "6090488311964275037", 784906157)
addappid(296225, 1, "825922585e97896e2ee71db7c2c7a75ef19af869befd3f864f84c7c45cc53cd1") -- Farm Frenzy 4 MAC
setManifestid(296225, "1869275993655263660", 926973884)
addappid(296226, 1, "6c0b1c3f21d6d08e1659b9c24381356a37ba0f9fb38ad1f934312b75b7e6eb59") -- Farm Frenzy 4 DUT
setManifestid(296226, "7565118450429285428", 784906157)
addappid(296227, 1, "c043e6c6384670b6bda9c25cc7b3c4caf5bf5fdff808462e9a8e01c1d0e44619") -- Farm Frenzy 4 FRE
setManifestid(296227, "8105862965296359527", 784906157)
addappid(296228, 1, "0347328109d24fcf45c7b6c0e8671f9ae09af77999cba9e4b382c9d8f2599d07") -- Farm Frenzy 4 ITA
setManifestid(296228, "146148493375446395", 784906157)
addappid(296229, 1, "f8ba323e81dabfd6a7c9d58066269af9104166f3c3e5d6e74813bafd1522bd07") -- Farm Frenzy 4 POR
setManifestid(296229, "8470035297656163136", 784906157)
addappid(296230, 1, "0c689f24826dcc08dd828a344c082d6f40f59b804db5b97280900603cee6a968") -- Farm Frenzy 4 SPA
setManifestid(296230, "831420740978736513", 784906157)
addappid(296231, 1, "91fd5206dcdd7be91beeba289c7405248512577ac68ab3e9d52a0dd528cacf7e") -- Farm Frenzy 4 SWE
setManifestid(296231, "5462546790766105249", 784906157)