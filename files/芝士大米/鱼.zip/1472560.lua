-- 1472560's Lua and Manifest Created by Hubcap Manifest
-- I Am Fish
-- Created: September 29, 2025 at 18:38:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1472560) -- I Am Fish
-- MAIN APP DEPOTS
addappid(1472561, 1, "6bef5b77e8fda2a7ee82a253648668dbdeb304d2b57d6c9f5f790febfc8b0b11") -- IamFish Content
setManifestid(1472561, "1189058342588675758", 11048524877)
addappid(1472562, 1, "ab88c1a0f08d5f7e531be35e21571389a263b7427179af0c36a5034ff00563e6") -- I Am Fish Extras
setManifestid(1472562, "1365806185189140546", 92950022)