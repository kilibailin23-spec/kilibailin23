-- 4108000's Lua and Manifest Created by Hubcap Manifest
-- Machine Party
-- Created: August 04, 2026 at 11:42:25 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4108000, 1, "d174fd71f1d5aea39b8c5db73d8a339d85664fdaef462a6d16e6d12b208e36f5") -- Machine Party
addtoken(4108000, "4276523766500984434")
-- MAIN APP DEPOTS
addappid(4108002, 1, "b3eec73467b0e15b4d743855abe06f39458e89099c0825b6fcc7dba2607eb77d") -- Depot 4108002
setManifestid(4108002, "1703975059497064890", 735991228)
addappid(4108003, 1, "4ac0783ec643cdbd5aca53b4a0d8b3d1d8197a4813824412d203db441c2dd7fd") -- Depot 4108003
setManifestid(4108003, "3507171820852513718", 709869844)