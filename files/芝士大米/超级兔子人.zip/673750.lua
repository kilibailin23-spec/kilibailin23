-- 673750's Lua and Manifest Created by Hubcap Manifest
-- Super Bunny Man
-- Created: July 24, 2026 at 06:52:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(673750, 1, "9086f1b2ada4e1b684662546b196aad2dafe70705b52a1151c840c002e33ee59") -- Super Bunny Man
-- MAIN APP DEPOTS
addappid(673751, 1, "ef8e2faa6ce07ab491309abf7236035899b0ffacebb9e67c94c43ef39e9db256") -- Super Bunny Man Content
setManifestid(673751, "5757779581101073559", 1291072688)
addappid(673752, 1, "ce41cc79d5435eace9ea012608624c9011832aa19b1177636544a8159ddefcf4") -- Depot 673752
setManifestid(673752, "6868561638579814382", 1315212587)
addappid(673753, 1, "69b83c4681d49f60187dec02af5734fdfe3f5f0d2bd446662abde2a607cf214e") -- Depot 673753
setManifestid(673753, "8963798596294226565", 1290330080)