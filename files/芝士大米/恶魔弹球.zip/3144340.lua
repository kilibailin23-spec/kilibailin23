-- 3144340's Lua and Manifest Created by Hubcap Manifest
-- Cult of PiN
-- Created: August 25, 2026 at 19:21:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3144340, 1, "b7ee8e9b7f3218c846578499ff19bfd65bbc02b02cc519b11f6adb3802628518") -- Cult of PiN
-- MAIN APP DEPOTS
addappid(3144341, 1, "aa6b4eaa736b5485f52bb878fb3cc3e91d8976fa26aabf0941c97f196132cef1") -- Depot 3144341
setManifestid(3144341, "1595483641052614323", 202197676)
addappid(3144342, 1, "832d54b3981b381fae0705dc665857724a1974f7df4be6db0a94c83a66bf71c6") -- Depot 3144342
setManifestid(3144342, "858418595576969426", 199784805)
addappid(3144343, 1, "8dd1dd2825cc942c4fe302ad0dc978c85a9269a58ec7f36b553ea8dfd33aa6c9") -- Depot 3144343
setManifestid(3144343, "7555356362840123791", 218413179)