-- 3117820's Lua and Manifest Created by Hubcap Manifest
-- Sultan's Game
-- Created: June 09, 2026 at 11:55:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3117820, 1, "5b953b3aff2ae34d4eee90a135eaee5a3e1377be9a5c4c6af9c218072aff7589") -- Sultan's Game
-- MAIN APP DEPOTS
addappid(3117821, 1, "6da5c61617ae1bce4dec442e070762a2b581103f5765d3067a24cc1276dd0461") -- Depot 3117821
setManifestid(3117821, "3336748597559446708", 2787325679)
addappid(3117822, 1, "035a90c8a84efd35f026f2ac3856c53f459fed40e95d99e490f0eed947a99be9") -- Depot 3117822
setManifestid(3117822, "3414575219633035271", 2824955510)
addappid(3117823, 1, "4041c78dfa1b7b56de279bbaf92f1bd964a745fd067e476ed3302d0a40b90042") -- Depot 3117823
setManifestid(3117823, "679070825395606123", 2882446536)
-- DLCS WITH DEDICATED DEPOTS
-- Sultans Game - Digital Novel (AppID: 3728320)
addappid(3728320)
addappid(3728320, 1, "6efd49cc3608ae57bc6d0b2e1c1f790c0b6febd6bd548587d1314e7c1acf35ef") -- Sultans Game - Digital Novel - Depot 3728320
setManifestid(3728320, "4532337905061516730", 106184925)