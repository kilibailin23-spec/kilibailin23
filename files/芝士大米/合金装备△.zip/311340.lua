-- 311340's Lua and Manifest Created by Hubcap Manifest
-- METAL GEAR SOLID V: GROUND ZEROES
-- Created: July 22, 2026 at 11:30:55 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(311340, 1, "5057539fa26099216ef1a32d4f2f486170b9321a8d904a4454694b7abd6e7a93") -- METAL GEAR SOLID V: GROUND ZEROES
-- MAIN APP DEPOTS
addappid(311344, 1, "b00a15399f6f765acf2f0f20d06bcfa10766cc6e2cdcfa4ed3e5731fa7cfbb5f") -- METAL GEAR SOLID V: GROUND ZEROES ENG CERO
setManifestid(311344, "2543357782612220046", 3038575063)
addappid(311341, 1, "e88d146d5d2a23261b9315001e2ab7344adac66e00194985e1f00b847e2e9dbc") -- Metal Gear Solid: Ground Zeroes Eng ESRB,PEGI
setManifestid(311341, "3088848911239715671", 3038661081)
addappid(311343, 1, "5498c3c90715a35f8e208cd6b380a16901cae634d9c22cb0f8a1cfed3f70b9cf") -- Metal Gear Solid V: Ground Zeroes Jpn ESRB,PEGI
setManifestid(311343, "1427650686339053933", 3082524361)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)