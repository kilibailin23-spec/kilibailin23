-- 2515020's Lua and Manifest Created by Hubcap Manifest
-- FINAL FANTASY XVI
-- Created: January 23, 2026 at 20:19:32 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 6

-- MAIN APPLICATION
addappid(2515020, 1, "2cde97a0aa99f50beb1ea949762d856a5ea6852541819cadd10e6624aff5dd4d") -- FINAL FANTASY XVI
-- MAIN APP DEPOTS
addappid(2515021, 1, "a1bc4011c581932ab613727be50494068bd3d57d59fa0f60bef081401902a046") -- Depot 2515021
setManifestid(2515021, "8473560965998297727", 136016506529)
addappid(2515022, 1, "3bf28fa5738f1732e7e31ca3de269b6690be6a325d2ce76da6f924ddf812b90b") -- Depot 2515022
setManifestid(2515022, "8458672795933688766", 8498226189)
-- DLCS WITH DEDICATED DEPOTS
-- FINAL FANTASY XVI Echoes of the Fallen (AppID: 2744050)
addappid(2744050)
addappid(2744050, 1, "bc72920eacff6d82dae14ecb5d72a42f4ecbba95f5aab7db874e4cea87e8801e") -- FINAL FANTASY XVI Echoes of the Fallen - Depot 2744050
setManifestid(2744050, "4732525787723924801", 11285282033)
-- addappid(2744051, 1, "MISSING_KEY") -- FINAL FANTASY XVI Echoes of the Fallen - Depot 2744051 (no key available)
-- FINAL FANTASY XVI The Rising Tide (AppID: 2744060)
addappid(2744060)
addappid(2744060, 1, "e57aab17d957ce339fc8bfa53c929fdaa17fa91f3355b40c9bd25e8ba1f1ff83") -- FINAL FANTASY XVI The Rising Tide - Depot 2744060
setManifestid(2744060, "8940147577278755183", 15897371067)
-- addappid(2744061, 1, "MISSING_KEY") -- FINAL FANTASY XVI The Rising Tide - Depot 2744061 (no key available)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2886900) -- FINAL FANTASY XVI Expansion Pass
addappid(3142080) -- FINAL FANTASY XVI - Brave Blade
addappid(3142090) -- FINAL FANTASY XVI - Cait Sith Charm
addappid(3142100) -- FINAL FANTASY XVI - Sixteen Bells Orchestrion Roll
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2515023) -- Depot 2515023 (empty depot)