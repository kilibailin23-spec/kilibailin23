-- 648800's Lua and Manifest Created by Hubcap Manifest
-- Raft
-- Created: April 05, 2026 at 09:25:42 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(648800, 1, "fcc79fc7fbc5d5fefdb2fc4b0bffef695b803edc0612e656861e6b362f2869ca") -- Raft
-- MAIN APP DEPOTS
addappid(648801, 1, "69b674ffb72cbe77ce081b29070056279accc29956cad5d38d31e0d3e2090632") -- Raft Content
setManifestid(648801, "4830832075480360897", 7773455514)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)