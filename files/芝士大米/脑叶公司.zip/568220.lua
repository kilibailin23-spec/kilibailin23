-- 568220's Lua and Manifest Created by Hubcap Manifest
-- Lobotomy Corporation
-- Created: September 29, 2025 at 22:26:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(568220, 1, "fa653f2dc25ab3fc344e141d5179f2fa7daae1455414ed988a0ca8d7c0d72e04") -- Lobotomy Corporation
-- MAIN APP DEPOTS
addappid(568221, 1, "4b83656636360e659df7b8f983d8436fe8216360fe0c6edf14f819a8622d70c7") -- Lobotomy Corporation |  Monster Management Simulation  Content
setManifestid(568221, "8058397718201736202", 5529460097)
-- DLCS WITH DEDICATED DEPOTS
-- LobotomyCorporation_ArtBook (AppID: 896000)
addappid(896000)
addappid(896000, 1, "76d7260e37893f7d0e8100d73d3685b1ebe2a0c8e71be8034d6f4c2d6596374b") -- LobotomyCorporation_ArtBook - LobotomyCroporation_ArtBook (896000) 개의 디포
setManifestid(896000, "4668171197035314231", 423777286)