-- 1940340's Lua and Manifest Created by Hubcap Manifest
-- Darkest Dungeon® II
-- Created: April 29, 2026 at 09:13:24 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 10
-- Total DLCs: 4

-- MAIN APPLICATION
addappid(1940340, 1, "813ac2fc24ad2efd41c269d79360b3514c9f55e28d0a1d6695425875b5aae0f3") -- Darkest Dungeon® II
-- MAIN APP DEPOTS
addappid(1940341, 1, "4266c37ee75bce9e4b3c5d16b0cffd8e21ed9ca98a95eed54900689ab5242d23") -- Depot 1940341
setManifestid(1940341, "2804281716747385054", 6055044601)
addappid(1940342, 1, "e9c92bd06c91103e6d6f07ae4be80184bb8a28fcb63018f3941d222048c45287") -- Depot 1940342
setManifestid(1940342, "6921223231235814305", 6119888330)
-- DLCS WITH DEDICATED DEPOTS
-- Darkest Dungeon II The Binding Blade (AppID: 2598510)
addappid(2598510)
addappid(2598510, 1, "235f932f22e943699a9dd3de36d77beb99ce3e99b25eea7d1467da814906bbde") -- Darkest Dungeon II The Binding Blade - Depot 2598510
setManifestid(2598510, "3821771715023000420", 235588639)
addappid(2598511, 1, "dbaaed9071a3364932fffa0e960be801e3abb368b91a3ebacb3bb0657e0cc6ca") -- Darkest Dungeon II The Binding Blade - Depot 2598511
setManifestid(2598511, "4484400011110533877", 235584776)
-- Darkest Dungeon II Inhuman Bondage (AppID: 3205310)
addappid(3205310)
addappid(3205310, 1, "36bbc8f34a0af50c71728ea98f60e80969087846308d321308eeacf180c72b81") -- Darkest Dungeon II Inhuman Bondage - Depot 3205310
setManifestid(3205310, "5558201690709026218", 431328315)
addappid(3205311, 1, "b1b962b48dd30d0bca610ea61a17f745d8e60bf227f5b60c93ce056739650224") -- Darkest Dungeon II Inhuman Bondage - Depot 3205311
setManifestid(3205311, "3624539004538354939", 431323282)
-- Darkest Dungeon II Infernal Supporter Pack (AppID: 3591040)
addappid(3591040)
addappid(3591040, 1, "bcb4dce50f021f662a8f4dc7765e5952186fdd6f4faad47e379af0b95202bebb") -- Darkest Dungeon II Infernal Supporter Pack - Depot 3591040
setManifestid(3591040, "1451016740324191040", 42494260)
addappid(3591041, 1, "b1d7efce3eca72ac0fb6a744e7a9969bc6f97bc90669d70d05da021ad21d603e") -- Darkest Dungeon II Infernal Supporter Pack - Depot 3591041
setManifestid(3591041, "7378219750337745171", 42494211)
-- Darkest Dungeon II Hero Origin Pack (AppID: 3715610)
addappid(3715610)
addappid(3715610, 1, "8509167b054fa6acac9084802a5cfe75c7e4956395a4b64adb307cef93bf2740") -- Darkest Dungeon II Hero Origin Pack - Depot 3715610
setManifestid(3715610, "3150497762967237829", 37765379)
addappid(3715611, 1, "d838b99999d23de2df264680d5c9d50adb82978a334dedc0d515885a3d467425") -- Darkest Dungeon II Hero Origin Pack - Depot 3715611
setManifestid(3715611, "3944379657338259985", 37765246)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4328940) -- Depot 4328940 (empty depot)
-- addappid(4328941) -- Depot 4328941 (empty depot)