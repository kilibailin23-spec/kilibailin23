-- 1190460's Lua and Manifest Created by Hubcap Manifest
-- DEATH STRANDING
-- Created: March 16, 2026 at 19:28:51 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1190460, 1, "ea98cff08eebc4e6640a61e64cbff84fc4b38884526721b1336aefeb2ecb785f") -- DEATH STRANDING
-- MAIN APP DEPOTS
addappid(1190461, 1, "ba4c72812b801fa2b777bbbb0e3bc51cdd4d5a96e9684b8d267d6273eb9d9552") -- Death Stranding Content
setManifestid(1190461, "6042070459325609651", 67702152321)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- DEATH STRANDING Digital Art Book (AppID: 1258510)
addappid(1258510)
addappid(1258510, 1, "f584e505fdec0face5332668d8732e56722854f0a1e3d54e7b8c5a6f40dd165a") -- DEATH STRANDING Digital Art Book - DEATH STRANDING Digital Art Book (1258510) Depot
setManifestid(1258510, "8715102423418115543", 103828745)
-- DEATH STRANDING Pre-Order Content (AppID: 1258610)
addappid(1258610)
addappid(1258610, 1, "800379eb2eac3ae22ec9e8da62e69ee31943887000f2b87b1fea64ba208e6f95") -- DEATH STRANDING Pre-Order Content - DEATH STRANDING Pre-Order Content (1258610) Depot
setManifestid(1258610, "2535244775118488795", 130407115)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1190464) -- Depot 1190464 (empty depot)
-- addappid(1190465) -- Depot 1190465 (empty depot)