-- 1721110's Lua and Manifest Created by Hubcap Manifest
-- Abyssus
-- Created: July 07, 2026 at 11:02:01 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1721110, 1, "84ff222c6c3b02088667934e3315d227bd86751a3ceee639b8683e0ffcc89feb") -- Abyssus
-- MAIN APP DEPOTS
addappid(1721111, 1, "fd31fe45269b1676240f9cabc945952eddc0eca492eed6d02938264d045af58b") -- Depot 1721111
setManifestid(1721111, "4875865485277280541", 5934027473)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3853680) -- Abyssus - Brinehunter Pack
addappid(3853790) -- Abyssus - Brineguard Pack
addappid(4168330) -- Abyssus - Brinefrost Pack
addappid(4508360) -- Abyssus - Brinerot Pack