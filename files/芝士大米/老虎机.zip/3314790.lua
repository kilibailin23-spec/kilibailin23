-- 3314790's Lua and Manifest Created by Hubcap Manifest
-- CloverPit
-- Created: April 14, 2026 at 15:48:56 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3314790, 1, "7f32b9cda5b8cffd32bfc4147e1264c1c25525c40196a30762eec09a85f97d83") -- CloverPit
-- MAIN APP DEPOTS
addappid(3314791, 1, "01f256d876a29ffa69ec7fefed5588393e85c3e5326497d7da92427e011759ff") -- Depot 3314791
setManifestid(3314791, "735106840404360210", 402202630)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4341120) -- CloverPit Unholy Fusion