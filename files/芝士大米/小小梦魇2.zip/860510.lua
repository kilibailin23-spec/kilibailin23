-- 860510's Lua and Manifest Created by Hubcap Manifest
-- Little Nightmares II
-- Created: September 29, 2025 at 22:21:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 6
-- Total DLCs: 4
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(860510) -- Little Nightmares II
-- MAIN APP DEPOTS
addappid(860511, 1, "b4785c13c7b51e8a08e3f16332ef4839c28d6e7544230b06535bd5ee180cbfea") -- Helios Content
setManifestid(860511, "1340413818607528556", 9395386926)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
setManifestid(229005, "7992454656023763365", 62009092)
-- DLCS WITH DEDICATED DEPOTS
-- Little Nightmares II Digital Content Bundle (AppID: 1282531)
addappid(1282531)
addappid(1282531, 1, "1bf86c1151867753629f54ffb559c02482ff71f34f59476a0a058093e0635ddd") -- Little Nightmares II Digital Content Bundle - Little Nightmares II - Pre-order Bonus DLC (1282531) Depot
setManifestid(1282531, "4972151890057558212", 1032157288)
-- Little Nightmares II Enhanced Edition (AppID: 1413420)
addappid(1413420)
addappid(1413420, 1, "8c10dd752f9e566421902b5f300bfc5098b40beaf62ba20c7ab8d223c1423dbf") -- Little Nightmares II Enhanced Edition - Helios - TEST004 (1413420) Depot
setManifestid(1413420, "2584754337176686908", 12969523279)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1282530) -- Little Nightmares II  Mokujin Hat
addappid(1282532) -- Little Nightmares II  The Nomes Attic