-- 1948280's Lua and Manifest Created by Hubcap Manifest
-- Stacklands
-- Created: September 30, 2025 at 19:21:54 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 2

-- MAIN APPLICATION
addappid(1948280, 1, "347776869e11602b2ea91e58bea4ad63b5c4265d2a3a4eb511e22a93e7109c11") -- Stacklands
-- MAIN APP DEPOTS
addappid(1948281, 1, "8dd1d5025c5a7f1f95e4b0daaf4207089bdab6bc74746dc37e27ae30b2cee8de") -- Depot 1948281
setManifestid(1948281, "5212363594900319791", 653051519)
addappid(1948282, 1, "6d4f901bb48c128e3d01f9ff294d6fe9bc02932d0ab0eeb9881d86cfef996dfb") -- Depot 1948282
setManifestid(1948282, "5367557022976073004", 680413504)
-- DLCS WITH DEDICATED DEPOTS
-- Stacklands Cursed Worlds (AppID: 2446110)
addappid(2446110)
addappid(2446110, 1, "ee6cab861739568f2ec3af0c3f4d6cb6ff49056d0b9d972633785776dbac536b") -- Stacklands Cursed Worlds - Depot 2446110
setManifestid(2446110, "3543188149032116646", 32077599)
-- Stacklands 2000 (AppID: 2867570)
addappid(2867570)
addappid(2867570, 1, "321d32b4b23d37a101e7cccbd57595abbd5752d7738c4a75189a6c6584374b29") -- Stacklands 2000 - Depot 2867570
setManifestid(2867570, "6353393087074861700", 39312696)