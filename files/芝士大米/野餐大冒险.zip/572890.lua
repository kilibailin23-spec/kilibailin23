-- 572890's Lua and Manifest Created by Hubcap Manifest
-- Pikuniku
-- Created: September 30, 2025 at 06:38:34 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(572890) -- Pikuniku
-- MAIN APP DEPOTS
addappid(572891, 1, "002409a0b848ba2e2d716bfdbcf7a99127727f61c4a6b88532c1f92bcd843d2c") -- Pikuniku Windows
setManifestid(572891, "9133632202559015182", 304757619)
addappid(572893, 1, "85665ed2edeb3474d1c15d78716336078f10c44da562c8713385c092598a9d7e") -- Pikuniku Windows x86
setManifestid(572893, "8933924394751383364", 299007347)
addappid(572892, 1, "45096d9f1ccc276dcc312a106a6333d4c11b4b9a246fed44241166e45f77108a") -- Pikuniku Mac
setManifestid(572892, "8455281620995956615", 319084548)
addappid(572894, 1, "2f2217e1086b46f659662f9ae4107eb3125bd70c2359801dfef3a77210288767") -- Pikuniku Linux
setManifestid(572894, "2106406371832602130", 351478002)
-- DLCS WITH DEDICATED DEPOTS
-- Pikuniku Soundtrack  Comic (AppID: 1016520)
addappid(1016520)
addappid(1016520, 1, "de3dcdeae5e646c7385bb032c68908235d0a8e15a039fc35cd80c4d363789edd") -- Pikuniku Soundtrack  Comic - Pikuniku Soundtrack + Comic (1016520) Depot
setManifestid(1016520, "5510651495465208623", 102396340)