-- 3947040's Lua and Manifest Created by Hubcap Manifest
-- Pegfinity
-- Created: August 21, 2026 at 14:56:02 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3947040, 1, "7431772261efc62fd587737d017fa77ac3d1529139632762309cb65e09023335") -- Pegfinity
-- MAIN APP DEPOTS
addappid(3947041, 1, "9e5e971647727eb87913197a387aac9441aef730b937d9e102d4d746d3b96338") -- Depot 3947041
setManifestid(3947041, "2700839749044740374", 112284332)