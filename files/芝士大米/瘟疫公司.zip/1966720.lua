-- 1966720's Lua and Manifest Created by Hubcap Manifest
-- Lethal Company
-- Created: April 16, 2026 at 22:52:45 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1966720, 1, "b1b18f9400b7b45bb7d3223ca7951a73cc2bdf0cb311e5b1a337e9c776c7ac7d") -- Lethal Company
-- MAIN APP DEPOTS
addappid(1966721, 1, "b79233b678dae6d3f928ff9c6c7674d559427776a1337dee238773a4fec60949") -- Depot 1966721
setManifestid(1966721, "6423525044216269478", 1753688893)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)