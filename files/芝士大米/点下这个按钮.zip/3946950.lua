-- 3946950's Lua and Manifest Created by Hubcap Manifest
-- Click the Button
-- Created: August 27, 2026 at 11:51:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3946950) -- Click the Button
-- MAIN APP DEPOTS
addappid(3946951, 1, "dbc3ed41113fd3842d880a61da7fb1ceb860fbf0d4fa251ff0d05185d1273e46") -- Depot 3946951
setManifestid(3946951, "517357601668668749", 165615332)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(5110650) -- Click the Button - Supporter Pack