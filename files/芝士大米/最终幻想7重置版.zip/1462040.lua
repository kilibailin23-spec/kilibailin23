-- 1462040's Lua and Manifest Created by Hubcap Manifest
-- FINAL FANTASY VII REMAKE INTERGRADE
-- Created: February 18, 2026 at 00:23:52 EST
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1462040, 1, "099720a08aaba50ae18e5334bedff270d2ac376c9d5bbc4ebf77b3e4da202875") -- FINAL FANTASY VII REMAKE INTERGRADE
-- MAIN APP DEPOTS
addappid(1462041, 1, "4e299a23f9a767cbb2ea9a71d2fd2334b46e66904c51f2478e1b54994e7d33a9") -- Depot 1462041
setManifestid(1462041, "7717118768461421712", 101392228737)
addappid(1462042, 1, "ac6881e562951d6369653f3e05bfbb32cb022208f25a950fd31e5045afe31498") -- Depot 1462042
setManifestid(1462042, "4652159271987585380", 6)
addappid(1462043, 1, "85dd87a3f14448b8659faa0acf1ec19c4213ea1096601adec258a00910b31cbb") -- Depot 1462043
setManifestid(1462043, "2245432882606591716", 4)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)