-- 424840's Lua and Manifest Created by Hubcap Manifest
-- Little Nightmares
-- Created: September 29, 2025 at 22:21:10 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 5
-- Total DLCs: 10
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(424840) -- Little Nightmares
-- MAIN APP DEPOTS
addappid(424841, 1, "1823f166b7f7161144cc3fb35ba96c0c8526183cf77e66127c44b152c1fcad7e") -- Little Nightmares Content
setManifestid(424841, "4926539991083375660", 9651035051)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Little Nightmares - Wallpaper - DLC 4 (AppID: 584093)
addappid(584093)
addappid(584093, 1, "55a230ea8309169f6d9a419934d5451c5a403fd07d721794c43e2ec41317d9ea") -- Little Nightmares - Wallpaper - DLC 4 - Little Nightmares - Wallpaper - DLC 4 (584093) Depot
setManifestid(584093, "8020948827316081497", 3206906)
-- Little Nightmares - Original Soundtrack (AppID: 601710)
addappid(601710)
addappid(601710, 1, "6ef5cd05ac17d226a1897c8bd1cee696e7ecd67372f84f357a61b1df8aa69949") -- Little Nightmares - Original Soundtrack - Little Nightmares – Original Soundtrack (601710) Depot
setManifestid(601710, "3933483467920670021", 116101371)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(584090) -- Little Nightmares - Scarecrow Sack - DLC 1
addtoken(584090, "1573258574440004267")
addappid(584091) -- Little Nightmares - Upside-down Teapot -DLC 2
addtoken(584091, "13416775076777956880")
addappid(584092) -- Little Nightmares - Tengu Mask
addappid(584094) -- Little Nightmares - Fox Mask
addappid(584095) -- Little Nightmares - The Depths
addappid(584096) -- Little Nightmares - The Hideaway
addappid(584097) -- Little Nightmares - The Residence DLC
addappid(640920) -- Little Nightmares - Secrets of The Maw Expansion Pass