-- 289650's Lua and Manifest Created by Hubcap Manifest
-- Assassin's Creed Unity
-- Created: August 24, 2026 at 05:32:57 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 7
-- Total DLCs: 18
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(289650, 1, "3341a55a14b60cb7d34c8d27af4f578e262cc7bef557a18b38bce40a29c6989b") -- Assassin's Creed Unity
-- MAIN APP DEPOTS
addappid(289651, 1, "8f869005c44f493f984aa111e49e96c4f64e69a4b4078cbfff77f01ce5bb7b8e") -- Assassin’s Creed Unity Content
setManifestid(289651, "3729509919120398706", 35610563637)
addappid(289653, 1, "8aa4b40cbc6dc05229d0cdd4f7fc19f1e5b0cebe991d6db3fec2f3ffb906d700") -- RUS
setManifestid(289653, "7016661070798178830", 5978369253)
addappid(289652, 1, "dd7b22e30a71132cc09a5e75b0d8b326d5a0716911cb3b63f6f656fafe0ddad1") -- WW
setManifestid(289652, "2679326884158097457", 9052986711)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "768541678728958832", 264458224)
-- DLCS WITH DEDICATED DEPOTS
-- Assassins Creed Unity - Dead Kings (AppID: 324333)
addappid(324333)
addtoken(324333, "841826460893811545")
addappid(324333, 1, "9b07cb83c48f76dd01431636c4dcfed721bbf6d70141900658c6ff573ac15d3c") -- Assassins Creed Unity - Dead Kings - Dead King (324333) Depot
setManifestid(324333, "4731501881144486504", 8318709893)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(324330) -- Assassins Creed Unity Season Pass
addappid(324331) -- Assassins Creed Unity Revolutionary Armaments Pack
addtoken(324331, "4803911381585436071")
addappid(324332) -- Assassins Creed Unity Secrets of the Revolution
addtoken(324332, "2536154635369062415")
addappid(330960) -- Assassins Creed Unity - WW Uplay Activation
addappid(330961) -- Assassins Creed Unity - RU Uplay Activation
addappid(330970) -- Assassins Creed Unity - WW Preorder Uplay Activation
addappid(330980) -- Assassins Creed Unity - RUCIS Preorder Uplay Activation
addappid(330981) -- Assassins Creed Unity - JP Preorder Uplay Activation
addappid(330982) -- Assassins Creed Unity - Gold WW Uplay Activation
addappid(330983) -- Assassins Creed Unity - Gold RUCIS Uplay Activation
addappid(330984) -- Assassins Creed Unity - Gold JP Uplay Activation
addappid(330985) -- Assassins Creed Unity - JP Uplay Activation
addappid(330986) -- Assassins Creed Unity - Season Pass Uplay Activation
addappid(330987) -- Assassins Creed Unity - Gold IND Uplay Activation
addappid(330988) -- Assassins Creed Unity - IND preorder Uplay Activation
addappid(331950) -- Assassins Creed Unity - IND Uplay Activation
addappid(344600) -- Assassins Creed Unity - Secret of the Revolution - Uplay Activation
addtoken(344600, "6410118437257689445")