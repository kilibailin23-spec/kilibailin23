-- 838380's Lua and Manifest Created by Hubcap Manifest
-- DEAD OR ALIVE 6
-- Created: July 30, 2026 at 07:03:33 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 64
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(838380, 1, "3954db49a58b078fc001215df5238df61508f6378227a2850de379c95c8aaddb") -- DEAD OR ALIVE 6
-- MAIN APP DEPOTS
addappid(838381, 1, "92fb6d22798bdbc124409edb818c41c9c3fd9d61ecbe63da822938138e9c402f") -- Release Data
setManifestid(838381, "4735425669633752101", 62557739432)
addappid(838382, 1, "260f44b05ec60bbf5e68d67ddd4ae78e648bb292eae12f9da97193fc00d5ffbe") -- Release App
setManifestid(838382, "574111364706793777", 45345488)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1033460) -- DOA6 Character Ayane
addtoken(1033460, "13360269898889445960")
addappid(1033470) -- DOA6 Character Tina
addtoken(1033470, "15238142599178128341")
addappid(1033471) -- DOA6 Character Leifang
addtoken(1033471, "5361349451755515067")
addappid(1033472) -- DOA6 Character Helena
addtoken(1033472, "9045571180509599884")
addappid(1033473) -- DOA6 Character Christie
addtoken(1033473, "5439780443710653218")
addappid(1033474) -- DOA6 Character Kokoro
addtoken(1033474, "15499212216936538789")
addappid(1033475) -- DOA6 Character La Mariposa
addtoken(1033475, "17663208581071504597")
addappid(1033476) -- DOA6 Character Mila
addtoken(1033476, "7740829313818471305")
addappid(1033477) -- DOA6 Character Marie Rose
addtoken(1033477, "12771691015090539907")
addappid(1033478) -- DOA6 Character Honoka
addtoken(1033478, "8959876260361863512")
addappid(1033479) -- DOA6 Character NiCO
addtoken(1033479, "12509055989826031019")
addappid(1033480) -- DOA6 Character Hayabusa
addtoken(1033480, "8305488345013854960")
addappid(1033481) -- DOA6 Character Hayate
addtoken(1033481, "15785577573015868638")
addappid(1033482) -- DOA6 Character Jann Lee
addtoken(1033482, "1640183750935869019")
addappid(1033483) -- DOA6 Character Zack
addtoken(1033483, "12274165726822007132")
addappid(1033484) -- DOA6 Character Bayman
addtoken(1033484, "5130655573315924963")
addappid(1033485) -- DOA6 Character Brad Wong
addtoken(1033485, "16375660702228433484")
addappid(1033486) -- DOA6 Character Eliot
addtoken(1033486, "16674356462863386661")
addappid(1033487) -- DOA6 Character Rig
addtoken(1033487, "13341369112030840651")
addappid(1033488) -- DOA6 Character Raidou
addtoken(1033488, "3022472106970559785")
addappid(1033489) -- DEAD OR ALIVE 6 Core Fighters 20 Character Set
addtoken(1033489, "15000446146281457064")
addappid(1033490) -- DOA6 Season Pass 1
addappid(1033491) -- DOA6 Season Pass 1 Bonus Costume NiCO
addtoken(1033491, "14124309683048313497")
addappid(1033492) -- DOA6 Season Pass 1 Bonus Costume Nyotengu
addtoken(1033492, "15443703180519279047")
addappid(1034470) -- DOA6 Story Unlock Key
addtoken(1034470, "12926584720767900251")
addappid(1034471) -- DOA6 Character Nyotengu
addtoken(1034471, "6158735455868223595")
addappid(1034480) -- DOA6 Character Phase4
addtoken(1034480, "8946727556844140187")
addappid(1034481) -- DOA6 Early Purchase Bonus Costume - Kasumi
addtoken(1034481, "11326258888400566827")
addappid(1034482) -- DOA6 Digital Deluxe Edition Bonus Costume - Kasumi
addtoken(1034482, "17136858179616171006")
addappid(1034483) -- DOA6 Deluxe BGM (3 tracks)
addtoken(1034483, "4490832916617145503")
addappid(1034484) -- DOA6 Deluxe Costume Set
addtoken(1034484, "9382758591433291531")
addappid(1042850) -- DOA6 Happy Wedding Costume Vol.1 Set
addappid(1042851) -- DOA6 Happy Wedding Costume Vol.2 Set
addappid(1048380) -- DEAD OR ALIVE 6 Core Fighters - Male Fighters Set
addappid(1048381) -- DEAD OR ALIVE 6 Core Fighters - Female Fighters Set
addappid(1054330) -- DEAD OR ALIVE 6 - Full Game
addtoken(1054330, "9632757680028342101")
addappid(1058120) -- DOA6 Pirates of the 7 Seas Costumes Vol.1 Set
addappid(1058121) -- DOA6 Pirates of the 7 Seas Costumes Vol.2 Set
addappid(1074260) -- DOA6 Character Mai Shiranui
addappid(1074261) -- DOA6 Happy Wedding Costume - Mai Shiranui
addappid(1074262) -- DOA6 Pirates of the 7 Seas Costume - Mai Shiranui
addappid(1074263) -- DOA6 Nurse Costume - Mai Shiranui
addappid(1074264) -- DOA6 Maid Costume - Mai Shiranui
addappid(1074265) -- DOA6 Bunny Costume - Mai Shiranui
addappid(1074266) -- DOA6 Mai Shiranui Debut Costume Set
addappid(1074267) -- DOA6 Mai Shiranui  Debut Costume Set
addappid(1074270) -- DOA6 Character Kula Diamond
addappid(1074271) -- DOA6 Happy Wedding Costume - Kula Diamond
addappid(1074272) -- DOA6 Pirates of the 7 Seas Costume - Kula Diamond
addappid(1074273) -- DOA6 Nurse Costume - Kula Diamond
addappid(1074274) -- DOA6 Maid Costume - Kula Diamond
addappid(1074275) -- DOA6 Bunny Costume - Kula Diamond
addappid(1074276) -- DOA6 Kula Diamond Debut Costume Set
addappid(1074277) -- DOA6 Kula Diamond  Debut Costume Set
addappid(1092291) -- DOA6  THE KING OF FIGHTERS XIV Mashup Content Set
addappid(1099190) -- DOA6 Happy Wedding Costume Vol.1 - Kasumi
addappid(1099191) -- DOA6 Happy Wedding Costume Vol.1 - Kokoro
addappid(1099200) -- DOA6 Happy Wedding Costume Vol.1 - Leifang
addappid(1099201) -- DOA6 Happy Wedding Costume Vol.1 - Hitomi
addappid(1099202) -- DOA6 Happy Wedding Costume Vol.1 - Marie Rose
addappid(1099203) -- DOA6 Happy Wedding Costume Vol.1 - Nyotengu
addappid(1099210) -- DOA6 Happy Wedding Costume Vol.1 - NiCO
addappid(1099211) -- DOA6 Happy Wedding Costume Vol.1 - Jann Lee
addappid(1099212) -- DOA6 Happy Wedding Costume Vol.1 - Hayabusa
-- EMPTY DEPOTS (no content on any branch)
-- addappid(838383) -- Depot 838383 (empty depot)
-- addappid(838384) -- Depot 838384 (empty depot)
-- addappid(838385) -- Depot 838385 (empty depot)
-- addappid(838386) -- Depot 838386 (empty depot)
-- addappid(838387) -- Depot 838387 (empty depot)
-- addappid(838388) -- Depot 838388 (empty depot)
-- addappid(838389) -- Depot 838389 (empty depot)
-- addappid(1033461) -- Depot 1033461 (empty depot)
-- addappid(1033462) -- Depot 1033462 (empty depot)