-- 641990's Lua and Manifest Created by Hubcap Manifest
-- The Escapists 2
-- Created: September 30, 2025 at 23:26:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 4
-- Total DLCs: 5
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(641990, 1, "3cad74989afb503f1fb211678e7e72510b12bf1cd75f2d69e75f30476a6d74e5") -- The Escapists 2
-- MAIN APP DEPOTS
addappid(641992, 1, "8c3af5e78c682bcf051a7eb58d709dff6af4aad4a97be9f80484a81ecd10d577") -- The Escapists 2 Windows
setManifestid(641992, "1586345527194870116", 2597321434)
addappid(641993, 1, "29057c4876f7ba3fcef935f9d0d5697f98c12481e81325e6e67c47b5dc77228a") -- The Escapists 2 OSX
setManifestid(641993, "1064841895391973752", 2248484330)
addappid(641994, 1, "1af8fc14e0c6fcbc4e13186ff8c04538029382e544aae3b31ed1145993143311") -- The Escapists 2 Linux
setManifestid(641994, "3855406764481817315", 2531914575)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(666350) -- The Escapists 2 - The Glorious Regime Prison
addappid(701180) -- The Escapists 2 - Season Pass
addappid(716580) -- The Escapists 2 - Wicked Ward
addappid(784930) -- The Escapists 2 - Big Top Breakout
addappid(821170) -- The Escapists 2 - Dungeons and Duct Tape