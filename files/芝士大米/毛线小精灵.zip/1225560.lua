-- 1225560's Lua and Manifest Created by Hubcap Manifest
-- Unravel
-- Created: July 27, 2026 at 07:46:20 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 9
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1225560, 1, "5c949f2031dc7681cbaccd93d6b7f7af4e31036a950c30a4f3611baff6f996b7") -- Unravel
-- MAIN APP DEPOTS
addappid(1225561, 1, "a140afd094a8bb6efc23d60e6a088a57d99f2ead57cd3e119a9990b5abdebffb") -- Unravel - Content
setManifestid(1225561, "5981616259209544595", 3411147986)
addappid(1225562, 1, "64d1780482ee7a08c13a0acf8927f30d860696d03519415bb60f718d211cdefa") -- Unravel - en_US
setManifestid(1225562, "5149303621573000052", 294777)
addappid(1225563, 1, "001937b3dd2dfcf42c785f9a48e4a12b251ccc7b9d6ff198f6a7a963853d8628") -- Unravel - fr_FR
setManifestid(1225563, "1951091726640725021", 313610)
addappid(1225564, 1, "7347c0c0c275e93edf997b1ebba400646f9a52234455e0435136dcec86f37645") -- Unravel - de_DE
setManifestid(1225564, "7740138130385322733", 175253)
addappid(1225565, 1, "05a4ab9741499d2783d38a9fdbf0db8175e0e407a0e4c278104336d635dec353") -- Unravel - it_IT
setManifestid(1225565, "5006667035594067337", 119722)
addappid(1225566, 1, "317d0e0fa7e2ddb0b704320a698d5a0a9606773c2dbe800993d665ec9584856f") -- Unravel - es_ES
setManifestid(1225566, "8199153259340925434", 302489)
addappid(1225567, 1, "8e39bae3abf6c34f170191f927c295cb9179410e53c1bd6e83d0f1066c1fbb9d") -- Unravel - ja_JP
setManifestid(1225567, "2748622227753890764", 710429)
-- SHARED DEPOTS (from other apps)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "6717304605949129056", 240979991)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1294930) -- Unravel - Key
addtoken(1294930, "11560506825038259258")