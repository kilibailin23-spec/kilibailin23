-- 1225570's Lua and Manifest Created by Hubcap Manifest
-- Unravel Two
-- Created: July 23, 2026 at 23:28:09 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 11
-- Total DLCs: 1
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(1225570, 1, "daa94d68ab9c9286e07017740bfebff7aff9e1d9f50103953c15d7814d01d846") -- Unravel Two
-- MAIN APP DEPOTS
addappid(1225571, 1, "bfce858492701c48e90b69a9bb8b6e75727d244141d4e65c24d70623208ee965") -- Unravel Two - Content
setManifestid(1225571, "4385080900375579352", 7562933306)
addappid(1225572, 1, "49a81f49ead1348c551713f50e75af7bce4af74de5a19f9246cacf465b5a5bb8") -- Unravel Two - en_US
setManifestid(1225572, "4749496822906332780", 140203)
addappid(1225573, 1, "d280c918fae8a156564bc0d93d9d68629413986db630e7d51aed031278438394") -- Unravel Two - de_DE
setManifestid(1225573, "8075218370122642547", 145578)
addappid(1225574, 1, "bb268ac48611b1139830d5c70a051594c339996762442ddaa2bd08534c612187") -- Unravel Two - es_ES
setManifestid(1225574, "1724278923015160224", 165182)
addappid(1225575, 1, "8e66a428751567b5e0d99c1bc39aca60946a767e0eca29d28b0581c114aa66e1") -- Unravel Two - fr_FR
setManifestid(1225575, "3562087141521819979", 158919)
addappid(1225576, 1, "76ecc115adc73c029729a373f5a7ddf4f364536eb05629e6d22df2afac2cc603") -- Unravel Two - it_IT
setManifestid(1225576, "3774875682025347959", 152750)
addappid(1225577, 1, "ca68bd4ee628af72fd03f078b10e0303f30365fb52984cf216deba9008900c39") -- Unravel Two - ja_JP
setManifestid(1225577, "8824693804216871054", 241743)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491") -- Depot 3340991 (Shared from App 3340990)
setManifestid(3340991, "6717304605949129056", 240979991)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1282800) -- Unravel Two - Key
addtoken(1282800, "1944708237892570150")