-- 1267910's Lua and Manifest Created by Hubcap Manifest
-- Melvor Idle
-- Created: September 30, 2025 at 00:19:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 3 (1 excluded)

-- MAIN APPLICATION
addappid(1267910) -- Melvor Idle
-- MAIN APP DEPOTS
addappid(1267911, 1, "2c7496aa9bd2af0b01037eb53e94883921ad093afa94350aee66e5e0b3c68a84") -- Melvor Idle Content
setManifestid(1267911, "349725829955010167", 724342889)
addappid(1267913, 1, "a8450c2daf53c9f6d9c7cd6a3bc13e267df6255590d6aac15a16a4f951b20a0c") -- Melvor Idle Depot Linux x64
setManifestid(1267913, "8875374614659965895", 831944273)
addappid(1267912, 1, "4cac0974efa6ca62ab12d6ce7bc2dc45f33b7a6368b00626b1177a09b2d986e1") -- Melvor Idle MacOS Depot
setManifestid(1267912, "8164613591265306544", 1222508150)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2055140) -- Melvor Idle Throne of the Herald
addappid(2492940) -- Melvor Idle Atlas of Discovery
addappid(2860590) -- Melvor Idle Into the Abyss
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(2129210) -- Melvor Idle: NOT USED (unreleased)