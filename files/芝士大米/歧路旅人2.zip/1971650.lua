-- 1971650's Lua and Manifest Created by Hubcap Manifest
-- OCTOPATH TRAVELER II
-- Created: September 30, 2025 at 04:25:08 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1971650) -- OCTOPATH TRAVELER II
-- MAIN APP DEPOTS
addappid(1971651, 1, "b27023dd7c9a1894c98a3a8a507f86f2e56bf2f7e611addb95eba15ea538ff5a") -- Depot 1971651
setManifestid(1971651, "1880363709147535524", 7938319601)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2133280) -- Travel Provisions