-- 1040200's Lua and Manifest Created by Hubcap Manifest
-- Crime Scene Cleaner
-- Created: May 19, 2026 at 13:15:30 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0 (1 excluded)

-- MAIN APPLICATION
addappid(1040200, 1, "3651c051a4a7c98a872929fc9e2994273629bf6724ec207f61fd933dc702bd01") -- Crime Scene Cleaner
-- MAIN APP DEPOTS
addappid(1040201, 1, "c674332af23f9b6fcc58092e93db43d62fe38a9b004985697e490bde97b45548") -- Depot 1040201
setManifestid(1040201, "902898025752593275", 56207660101)
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4492060) -- Crime Scene Cleaner - Biohazard (unreleased)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4492060) -- Depot 4492060 (empty depot)