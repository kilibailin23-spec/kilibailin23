-- 2379780's Lua and Manifest Created by Hubcap Manifest
-- Balatro
-- Created: September 28, 2025 at 23:59:43 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2379780) -- Balatro
-- MAIN APP DEPOTS
addappid(2379781, 1, "16261e41d3e864018778d4a1d81658521a67d9ffb8543ea7e3e21f0685721af1") -- Depot 2379781
setManifestid(2379781, "3512319404653808464", 66662933)
addappid(2379782, 1, "d0d563bdb51d625d0ed3a3234be0282f8d9a25d81dce599cdcace7b88c3b4719") -- Depot 2379782
setManifestid(2379782, "1898957422191678575", 85164047)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)